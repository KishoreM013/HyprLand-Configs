#!/bin/bash

# Define options
options="⏻ Shutdown\n Reboot\n Lock\n Suspend\n Hibernate\n Logout"

# Launch Wofi with minimal padding and centered text
choice=$(echo -e "$options" | wofi --dmenu --prompt "Power Menu" --width=300 --height=700 --lines=6)

# Strip icons if needed
action=$(echo "$choice" | awk '{print $2}')

case "$action" in
  Shutdown)
    systemctl poweroff
    ;;
  Reboot)
    systemctl reboot
    ;;
  Lock)
    if command -v swaylock >/dev/null; then
      swaylock
    elif command -v gtklock >/dev/null; then
      gtklock
    else
      notify-send "No lock utility found!"
    fi
    ;;
  Suspend)
    systemctl suspend
    ;;
  Hibernate)
    systemctl hibernate
    ;;
  Logout)
    if [ "$XDG_SESSION_DESKTOP" = "sway" ]; then
      swaymsg exit
    elif [ "$XDG_SESSION_DESKTOP" = "hyprland" ]; then
      hyprctl dispatch exit
    elif [ "$XDG_SESSION_DESKTOP" = "wayfire" ]; then
      loginctl terminate-user $USER
    else
      notify-send "Logout not configured for this session."
    fi
    ;;
esac
