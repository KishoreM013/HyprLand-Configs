sudo pacman -S hypr
sudo pacman -S git
sudo pacman -S btop
sudo pacman -S brightnessctl
sudo pacman -S waybar
sudo pacman -S alacritty
sudo pacman -S mpd
yay -S hypridle
yay -S hyprlock
yay -S hyprpaper
yay -S hyprcursor
